package com.cg.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
@Entity
public class User {
	@Id
	@Column(name="userName", unique = true, columnDefinition="VARCHAR(50)")
	private String username;
	private String password;
	private String name;
	private String email;
	private String contact;
	private String assignedBook;
	private Date issuedDate;
	private Date returnDate;
	private boolean returnStatus;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getAssignedBook() {
		return assignedBook;
	}
	public void setAssignedBook(String assignedBook) {
		this.assignedBook = assignedBook;
	}
	public Date getIssuedDate() {
		return issuedDate;
	}
	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public boolean isReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(boolean returnStatus) {
		this.returnStatus = returnStatus;
	}
	@Override
	public String toString() {
		return "User [ username=" + username + ", password=" + password + ", name=" + name + ", email="
				+ email + ", contact=" + contact + ", assignedBook=" + assignedBook + ", issuedDate=" + issuedDate
				+ ", returnDate=" + returnDate + ", returnStatus=" + returnStatus + "]";
	}
	
	
	
	
		
	
	
}



