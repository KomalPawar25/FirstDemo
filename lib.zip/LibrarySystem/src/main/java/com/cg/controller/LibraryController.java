package com.cg.controller;





import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Admin;
import com.cg.bean.Book;

import com.cg.bean.User;
import com.cg.service.LibraryService;

@Controller
public class LibraryController {
	@Autowired	
	LibraryService service;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index() {
		return "index";
	}
	@RequestMapping(path = "/Adminlogin", method = RequestMethod.GET)
	public String getStared(@ModelAttribute("admin") Admin admin) {
		return "admin_login";
	}
	
	
	@RequestMapping(path = "/Userlogin", method = RequestMethod.GET)
	public String getStared(@ModelAttribute("user") User user) {
		return "user_login";
	}
	
	
	@RequestMapping(path = "/homepage", method = RequestMethod.GET)
	public String goToHomePage() {
		return "menu";
	}

@RequestMapping(path = "/operations", method = RequestMethod.POST)
public ModelAndView auth(@ModelAttribute("admin") Admin admin) {

	ModelAndView mv = new ModelAndView();
	if (admin.getUsername().equals("admin") && admin.getPassword().equals("12345")) {
		mv.setViewName("admin_func");
		System.out.println("Authenticated ...");
	} else {
		mv.setViewName("admin_login");
		System.out.println("Wrong username and password");
	}

	return mv;

}
/*@RequestMapping(path = "/operations1", method = RequestMethod.POST)
public ModelAndView auth(@ModelAttribute("user") User user) {

	ModelAndView mv = new ModelAndView();
	
		mv.setViewName("user_func");
		return mv;

}
*/


// B O O K


@RequestMapping(path = "/addBook", method = RequestMethod.GET)
public ModelAndView auth(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("addBook");

	return mv;

}



@RequestMapping(path = "getboookData", method = RequestMethod.POST)
public ModelAndView addTrainee(@ModelAttribute("bk") Book book, BindingResult result) {

	ModelAndView mv = new ModelAndView();
	String res = service.addBook(book, result);
	
	
	mv.addObject("res", res);
	mv.setViewName("addBook");
	return mv;
}

@RequestMapping(path = "/deleteBook", method = RequestMethod.GET)
public ModelAndView deleteBookById(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("delete");

	return mv;

}

@RequestMapping(path = "deleteBook", method = RequestMethod.POST)
public ModelAndView deleteBookId(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	String res = service.deleteBook(book);
	
	
	mv.addObject("res", res);
	mv.setViewName("delete");
	return mv;
}


@RequestMapping(path = "/modifyBook", method = RequestMethod.GET)
public ModelAndView updateBook(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("modifyBook");

	return mv;

}

@RequestMapping(path = "modifyBook", method = RequestMethod.POST)
public ModelAndView UpdateBookById(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	Book b = service.updateBook(book);
	
	
	mv.addObject("res", b);
	mv.setViewName("modifyBook");
	return mv;
}


@RequestMapping(path = "/getBookById", method = RequestMethod.GET)
public ModelAndView getBookId(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("getBookById");

	return mv;

}

@RequestMapping(path = "getBookById", method = RequestMethod.POST)
public ModelAndView getBookById(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	Book b = service.getBookById(book.getbId());
	
	
	mv.addObject("res", b);
	mv.setViewName("getBookById");
	return mv;
}


@RequestMapping(path = "/getAllBooks", method = RequestMethod.GET)
public ModelAndView getAll() {

	
	ModelAndView mv = new ModelAndView();

	List<Book> list = new ArrayList<Book>();
	list = service.getAllBook();
	mv.addObject("blist", list);
	
	mv.setViewName("getAllBooks");
	return mv;

}


// U S E R

@RequestMapping(path = "/manageUsers", method = RequestMethod.GET)
public ModelAndView manageUser(@ModelAttribute("user") User user) {

	ModelAndView mv = new ModelAndView();
	
		mv.setViewName("admin_user_func");
		return mv;

}


@RequestMapping(path = "/addUser", method = RequestMethod.GET)
public ModelAndView addUser(@ModelAttribute("uk") User user) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("addUser");

	return mv;

}



@RequestMapping(path = "getuserData", method = RequestMethod.POST)
public ModelAndView addTrainee(@ModelAttribute("uk") User user, BindingResult result) {

	ModelAndView mv = new ModelAndView();
	String res = service.addUser(user, result);
	
	
	mv.addObject("res", res);
	mv.setViewName("addUser");
	return mv;
}

@RequestMapping(path = "/deleteUser", method = RequestMethod.GET)
public ModelAndView deleteUserById(@ModelAttribute("uk") User user) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("deleteUsers");

	return mv;

}

@RequestMapping(path = "deleteUser", method = RequestMethod.DELETE)
public ModelAndView deleteUserId(@ModelAttribute("uk") User user) {

	ModelAndView mv = new ModelAndView();
	String res = service.deleteUser(user);
	
	
	mv.addObject("res", res);
	mv.setViewName("deleteUsers");
	return mv;
}


@RequestMapping(path = "/serch", method = RequestMethod.GET)
public ModelAndView searchBookByNAme(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("demo");

	return mv;

}

// Search book by name

@RequestMapping(path = "serch", method = RequestMethod.POST)
public ModelAndView searchBook(@ModelAttribute("bk") Book book) {

	ModelAndView mv = new ModelAndView();
	List<String> res = service.getBookbyName(book.getBookName());
	
	
	mv.addObject("res", res);
	mv.setViewName("demo");
	return mv;
}

// U S E R


@RequestMapping(path = "/userLogin", method = RequestMethod.GET)
public ModelAndView userLoginPage(@ModelAttribute("user") User user) {

	ModelAndView mv = new ModelAndView();
	mv.setViewName("user_login");

	return mv;

}

@RequestMapping(path = "userLogin", method = RequestMethod.POST)
public ModelAndView userLogin(@ModelAttribute("user") User user) {

	ModelAndView mv = new ModelAndView();
	boolean flag = service.loginUser(user);
	if(flag != true) {
		
		mv.addObject("Flogin","Invalid User");
		mv.setViewName("user_login");
		
	}
	
	else {
		
	mv.setViewName("user_func");
	}
	return mv;
}

@RequestMapping(path = "/getBooks", method = RequestMethod.GET)
public ModelAndView gwtbookname(@ModelAttribute("uk") Book book, ModelMap map) {

	ModelAndView mv = new ModelAndView();
	List<Book> list = new ArrayList<Book>();
	list = service.getDropDownBook();
	mv.addObject("blist", list);
	mv.setViewName("allBooks");
	User u = new User();
	Book b = new Book();
	
	map.addAttribute("u",u);
	map.addAttribute("b",b);

	return mv;

}

@RequestMapping(path = "getBooks", method = RequestMethod.POST)
public ModelAndView getbookbyName(@ModelAttribute("b") Book book, BindingResult result, @ModelAttribute("u") User user, BindingResult rest) {

	ModelAndView mv = new ModelAndView();
	List<Book> list = new ArrayList<Book>();
	list = service.getDropDownBook();
	mv.addObject("blist", list);
	
	User u = service.updateUser(user,book);
	
	mv.addObject("User",u);
	
	mv.setViewName("allBooks");
	return mv;
}


}
