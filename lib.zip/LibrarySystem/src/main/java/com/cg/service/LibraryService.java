package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;

import com.cg.bean.Book;
import com.cg.bean.User;
import com.cg.dao.ILibraryDao;

public class LibraryService implements ILibraryService {
	@Autowired
	ILibraryDao dao;

	public LibraryService(ILibraryDao dao) {
		super();
		this.dao = dao;
	}

	public ILibraryDao getDao() {
		return dao;
	}

	public void setDao(ILibraryDao dao) {
		this.dao = dao;
	}

	@Override
	public String addBook(Book book, BindingResult result) {
		// TODO Auto-generated method stub
		if(result.hasErrors())
        {
            return "Error";
        }
		dao.addBook(book);
		return "S U C C E S S";
	}

	@Override
	public String deleteBook(Book book) {
		// TODO Auto-generated method stub
		
		return dao.deleteBook(book);
	}

	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		return dao.updateBook(book);
	}

	@Override
	public Book getBookById(int id) {
		// TODO Auto-generated method stub
		return dao.getBookById(id);
	}

	@Override
	public List<Book> getAllBook() {
		// TODO Auto-generated method stub
		return dao.getAllBook();
	}

	@Override
	public String addUser(User user, BindingResult result) {
		// TODO Auto-generated method stub
		if(result.hasErrors())
        {
            return "Error";
        }
		dao.addUser(user);
		return "S U C C E S S";
	}

	@Override
	public String deleteUser(User user) {
		// TODO Auto-generated method stub
		return dao.deleteUser(user);
	}

	@Override
	public boolean loginUser(User user) {
		// TODO Auto-generated method stub
		return dao.loginUser(user);
	}

	@Override
	public List<String> getBookbyName(String name) {
		// TODO Auto-generated method stub
		return dao.getBookbyName(name);
	}

	@Override
	public List<Book> getDropDownBook() {
		// TODO Auto-generated method stub
		return dao.getDropDownBook();
	}

	@Override
	public User updateUser(User user, Book book) {
		// TODO Auto-generated method stub
		return dao.updateUser(user,book);
	}

	
	
	
}
