package com.cg.service;

import java.util.List;

import org.springframework.validation.BindingResult;

import com.cg.bean.Book;
import com.cg.bean.User;

public interface ILibraryService {

	public String addBook(Book book, BindingResult result);
	public String deleteBook(Book book);
	public Book updateBook(Book book);
	public Book getBookById(int id);
	public List<Book> getAllBook();
	public String addUser(User user, BindingResult result);
	public String deleteUser(User user);
	public List<String> getBookbyName(String name);
	
	// U S E R
	
	public boolean loginUser(User user);
	public List<Book> getDropDownBook();
	public User updateUser(User user,Book book);
}
