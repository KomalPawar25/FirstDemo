package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.cg.bean.Book;
import com.cg.bean.User;


@Transactional
public class LibraryDao implements ILibraryDao {
	@PersistenceContext
    EntityManager em;

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		em.persist(book);
		
	}

	@Override
	public String deleteBook(Book book) {
		// TODO Auto-generated method stub
		Book b = em.find(Book.class, book.getbId());
		em.remove(b);
		return "D E L E T E";
	}

	@Override
	public Book updateBook(Book book) {
		Book b = em.find(Book.class, book.getbId());
		b.setAuthorName(book.getAuthorName());
		b.setBookName(book.getBookName());
		b.setBookPrice(book.getBookPrice());
		b.setStatus(book.isStatus());
		
		em.persist(b);
		return b;
	}

	@Override
	public Book getBookById(int id) {
		Book b = em.find(Book.class, id);
		if(b!=null) { return b; }
		else return null; 
		//return null;
	}
	
	
// Ye method fetch all ke liye hai.
	@Override
	public List<Book> getAllBook() {
		List<Book> bookList = em.createQuery("SELECT t FROM Book t").getResultList();

		if (bookList == null) {
			return null;
		} else 

		return bookList;
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		em.persist(user);
		
	}

	@Override
	public String deleteUser(User user) {
		// TODO Auto-generated method stub
		User u = em.find(User.class, user.getUsername());
		em.remove(u);
		return "D E L E T E";
	}

	@Override
	public boolean loginUser(User user) {
		// TODO Auto-generated method stub
		User ux  = em.find(User.class,user.getUsername());
		if(ux == null) return false;
		if(ux.getUsername().equals(user.getUsername()) && ux.getPassword().equals(user.getPassword())) {
			return true;
		}
		
		else return false;
		
	}

	@Override
	public List<String> getBookbyName(String name) {
		// TODO Auto-generated method stub
		String query="select b.bookName from Book b where b.bookName = " +name;
		List<String> bookname=em.createQuery(query).getResultList();
		return bookname;
	}
	
	@Override
	public List<Book> getDropDownBook() {
		List<Book> bookList = em.createQuery("SELECT t.bookName FROM Book t").getResultList();

		if (bookList == null) {
			return null;
		} else 

		return bookList;
	}

	@Override
	public User updateUser(User user, Book book) {
		User u = em.find(User.class, user.getUsername());
		u.setAssignedBook(book.getBookName());
		u.setReturnStatus(false);
		em.persist(u);
		return u;
	}
	
	
    
}
