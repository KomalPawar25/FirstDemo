package com.cg.dao;

import java.util.List;

import com.cg.bean.Book;
import com.cg.bean.User;


public interface ILibraryDao {
	
	public void addBook(Book book);
	public String deleteBook(Book book);
	public Book updateBook(Book book);
	public Book getBookById(int id);
	public List<Book> getAllBook();
	public void addUser(User user);
	public String deleteUser(User user);
	public List<String> getBookbyName(String name);
	// U S E R
	
	public boolean loginUser(User user);
	public List<Book> getDropDownBook();
	public User updateUser(User user, Book book);
}
